# Evidence checklist before submission

Capture real screenshots for each item:
- [ ] W3C Markup Validation Service result for the published page or HTML source.
- [ ] Mobile layout (viewport narrower than 772px).
- [ ] Tablet layout (viewport 772px to 991px).
- [ ] Large-screen layout (viewport 992px or wider).
- [ ] Dark mode enabled in your operating system/browser.
- [ ] Reduced-motion preference enabled and page tested.
- [ ] WAVE report, including any contrast issues you fixed.
- [ ] CSS `style.css` showing the media queries and preference queries.

Do not claim validation passed until you have run the validators and fixed any errors.
