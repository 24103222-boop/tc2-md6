# Responsive Web Design with User Preferences

## Project Overview
My project is a responsive website featuring a gallery of nature photographs. The layout adapts to different screen sizes and respects users' display preferences.

## Responsive Design
- **Mobile view:** Uses a one-column CSS Grid layout with a 10px gap.
- **Tablet view (772px and above):** Changes to two columns, makes the figures circular, and allows the last figure to span both columns.
- **Large-screen view (992px and above):** Removes rounded corners and makes every third figure span both columns.

## Accessibility and User Preferences
- Every image includes descriptive alternative text.
- The website uses semantic HTML elements.
- The `prefers-reduced-motion` media query disables smooth scrolling and minimizes animations and transitions.
- The `prefers-color-scheme: dark` media query changes the page to a dark color scheme with lighter text.

## CSS Styling
The website uses CSS Grid, media queries, spacing, borders, image sizing, and separate styling rules for different viewport sizes.

## Validation and Testing
The HTML should be checked using the W3C Markup Validation Service. The website should also be tested at mobile, tablet, and desktop widths, and checked with WAVE for accessibility and color-contrast issues. Screenshots of the validation results and responsive layouts should be included as evidence.

## Four Additional Features
1. Responsive layouts for mobile, tablet, and large screens.
2. A dark color scheme based on the user's system preference.
3. Reduced-motion support for users who prefer less animation.
4. Descriptive image alternative text to improve accessibility.

## Conclusion
This project demonstrates my understanding of responsive web design, CSS Grid, media queries, accessibility, and user preference settings.
