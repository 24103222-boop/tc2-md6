RESPONSIVE WEB DESIGN WITH USER PREFERENCES
Submission support package

Contents:
- project_description.md: ready-to-copy project description
- evidence_checklist.md: evidence you should capture before submitting
- website_url.txt: place your published GitHub Pages URL here

Important:
This package does not contain screenshots proving validation or a live website URL.
Run the W3C validator and WAVE yourself, test the site at mobile/tablet/desktop widths,
capture real screenshots, and replace the placeholder URL before submitting.
